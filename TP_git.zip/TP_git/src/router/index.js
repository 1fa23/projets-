import { createRouter, createWebHashHistory } from 'vue-router'
import Home from '../views/Home.vue'
import AddJob from "../views/AddJob.vue"
import EditJob from "../views/EditJob.vue"

const routes = [
  {
    path: '/',
    name: 'home',
    component: Home
  },

  {
    path: '/add',
    name: 'addJob',
    component: AddJob
  },
  {
    path: '/addEdit',
    name: 'Edit',
    component: EditJob
  }
  
]

const router = createRouter({
  history: createWebHashHistory(),
  routes
})

export default router
