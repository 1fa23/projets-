<template>
    <h3>Listes des produits en detail</h3>
    <div class="post-container" v-for="emploi in emplois" :key=emploi.id>
       
           <p>{{ emploi.title }}</p>
           <p>{{ emploi.description }}</p>
           <p>{{ emploi.salaire }}</p>
           <p>{{ emploi.date_de_creation }}</p>


    </div>
</template>

<script>
import { getPosts } from "@/composables/getPosts.js";
export default {
    name: "JobDetail",
    data() {
      return {
        emplois: []
      };
    },
    async mounted() {
      try {
          this.Posts = await getPosts();
      } catch (error) {
          console.error("Erreur lors de la récupération des articles :", error);
      } finally {
          this.loading = false;
      }
  }
}

</script>

<style scoped>
.post-container {
    background: #f9f9f9;
    padding: 15px;
    border-radius: 8px;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    margin-bottom: 10px;
}

h3 {
    color: #2c3e50;
    margin-bottom: 10px;
}

p {
    color: #555;
    line-height: 1.5;
}

</style>