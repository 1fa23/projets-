<template>
    <nav>
      <ul>
        <li><router-link to="/">Home</router-link></li>
        <li><router-link to="/addPost">addPost</router-link></li>
        <li><router-link to="/EditPost">EditPost</router-link></li>
      </ul>
    </nav>
  </template>
  
  <script>
  export default {
    name: "NavBar",
  }
  </script>
  