<template>
  <div>
    <h2>Liste des voitures</h2>
    <input type="text" v-model="filterText" placeholder="Rechercher une voiture..." />

    <ul>
      <li v-for="voiture in filteredVoitures" :key="voiture.id">
        <i>{{ voiture.description }}</i>
        <button @click="ajouterAuPanier(voiture)">Ajouter dans le panier</button>
      </li>
    </ul>
  </div>
</template>

<script>
import { getPosts } from "@/composables/getPosts.js";

export default {
  name: "ListeVoitures",
  data() {
    return {
      voitures: [],
      filterText: ""
    };
  },
  async mounted() {
    try {
      this.voitures = await getPosts(); // <- correction ici aussi
    } catch (error) {
      console.error("Erreur lors de la récupération des voitures :", error);
    }
  },
  computed: {
    filteredVoitures() {
      return this.voitures.filter(voiture =>
        voiture.description.toLowerCase().includes(this.filterText.toLowerCase())
      );
    }
  },
  methods: {
  ajouterAuPanier(voiture) {
    let panier = JSON.parse(localStorage.getItem("monPanier")) || [];
    // éviter les doublons
    if (!panier.find(item => item.id === voiture.id)) {
      panier.push(voiture);
      localStorage.setItem("monPanier", JSON.stringify(panier));
    }
    this.$router.push("/panier");
  }
}

};
</script>








<template>
  <div>
    <h2>Mon Panier</h2>
    <div v-if="panier.length === 0">
      <p>Le panier est vide.</p>
    </div>
    <ul v-else>
      <li v-for="voiture in panier" :key="voiture.id">
        <strong>{{ voiture.description }}</strong>
        <button @click="supprimerDuPanier(voiture.id)">Supprimer</button>
      </li>
    </ul>
  </div>
</template>

<script>
export default {
  name: "Panier",
  data() {
    return {
      panier: []
    };
  },
  mounted() {
    const savedPanier = localStorage.getItem("monPanier");
    this.panier = savedPanier ? JSON.parse(savedPanier) : [];
  },
  methods: {
    supprimerDuPanier(id) {
      this.panier = this.panier.filter(item => item.id !== id);
      localStorage.setItem("monPanier", JSON.stringify(this.panier));
    }
  }
};
</script>


  