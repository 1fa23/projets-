<template>
    <div class="form-container">
        <h2>{{ isEditMode ? "Modifier l'emploi" : "Formulaire d'ajout d'un emploi" }}</h2>
        <form @submit.prevent="submitForm">
            <label for="title">Titre :</label>
            <input type="text" id="title" v-model="formData.title" required>

            <label for="description">Description :</label>
            <textarea id="description" v-model="formData.description" required></textarea>

            <label for="salaire">Salaire :</label>
            <input type="text" id="salaire" v-model="formData.salaire" required>

            <label for="date_de_creation">Date de création : (année-mois-jour)</label>
            <input type="text" id="date_de_creation" v-model="formData.date_de_creation" required>
            <span :class="datavalide ? 'valid' : 'invalid'">
                {{ datavalide ? "Date valide" : "Date non valide" }}
            </span>

            <button type="submit" :disabled="!formValide">{{ isEditMode ? "Modifier" : "Ajouter" }}</button>
        </form>
    </div>
</template>

<script>
export default {
    props: {
        jobId: {
            type: String,
            default: null
        }
    },
    data() {
        return {
            formData: {
                title: "",
                description: "",
                salaire: "",
                date_de_creation: "",
            },
            isEditMode: false
        };
    },
    computed: {
        datavalide() {
            const regex = /^\d{4}-(0[1-9]|1[0-2])-(0[1-9]|[12]\d|3[01])$/;
            return regex.test(this.formData.date_de_creation);
        },
        formValide() {
            return this.datavalide && this.formData.title && this.formData.description && this.formData.salaire && this.formData.date_de_creation;
        }
    },
    methods: {
        getPost(id) {
            return fetch(`http://localhost:3000/posts/${id}`)
                .then(res => {
                    if (!res.ok) {
                        throw new Error(`Erreur HTTP! Statut : ${res.status}`);
                    }
                    return res.json();
                })
                .then(data => {
                    console.log("Article récupéré :", data);
                    return data;
                })
                .catch(err => {
                    console.error("Erreur lors du chargement de l'article :", err);
                    return null;
                });
        },
        loadJob() {
            // si jobId est definie 
            if (this.jobId) {
                this.getPost(this.jobId).then(data => {
                    if (data) {
                        this.formData = {
                            title: data.title,
                            description: data.description,
                            salaire: data.salaire,
                            date_de_creation: data.date_de_creation
                        };
                        this.isEditMode = true;
                    }
                });
            }
        },
        submitForm() {
            if (this.isEditMode) {
                // Logique pour mettre à jour l'emploi existant
                console.log("Mettre à jour l'emploi :", this.formData);
            } else {
                // Logique pour ajouter un nouvel emploi
                console.log("Ajouter un nouvel emploi :", this.formData);
            }
        }
    },
    mounted() {
        this.loadJob();
    }
};
</script>
