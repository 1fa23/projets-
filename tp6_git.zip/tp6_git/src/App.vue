<template>
  <nav>
      <div class="nav-container">
          <router-link to="/">Home</router-link>
          <router-link to="/addPost">Add Post</router-link>
          <router-link to="/EditPost">Edit Post</router-link>
      </div>
  </nav>
  <router-view/>
</template>

<style scoped>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
}

nav {
  background: #f8f9fa;
  padding: 15px;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
}

.nav-container {
  display: flex;
  justify-content: center;
  gap: 20px;
}

nav a {
  font-weight: bold;
  color: #2c3e50;
  text-decoration: none;
  padding: 10px 15px;
  border-radius: 5px;
  transition: background 0.3s ease;
}

nav a:hover {
  background: #e3e3e3;
}

nav a.router-link-exact-active {
  color: white;
  background: #42b983;
}
</style>
