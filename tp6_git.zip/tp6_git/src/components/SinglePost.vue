<template>
    <div class="post-container">
        <h3>{{ post.title }}</h3>
        <p>{{ post.content }}</p>
        <div class="tags">
            <span v-for="tg in post.tags" :key="tg" class="tag">#{{ tg }}</span>
        </div>
    </div>
</template>

<script>
export default {
    name: "SinglePost",
    props: {
        post: {
            type: Object,
            required: true
        }
    }
}
</script>

<style scoped>
.post-container {
    background: #f9f9f9;
    padding: 15px;
    border-radius: 8px;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    margin-bottom: 10px;
}

h3 {
    color: #2c3e50;
    margin-bottom: 10px;
}

p {
    color: #555;
    line-height: 1.5;
}

.tags {
    margin-top: 10px;
}

.tag {
    display: inline-block;
    background: #42b983;
    color: white;
    padding: 5px 10px;
    border-radius: 5px;
    font-size: 14px;
    margin-right: 5px;
}
</style>