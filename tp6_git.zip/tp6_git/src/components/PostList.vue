<template>
  <div>
      <h2>Listes des posts du blog</h2>
      <SinglePost v-for="post in Posts" :key="post.id" :post="post"></SinglePost>
  </div>
</template>

<script>
import { getPosts } from "@/composables/getPosts.js";
import SinglePost from "./SinglePost.vue";

export default {
  name: "PostList",
  data() {
      return {
          Posts: []
      };
  },
  components: {
      SinglePost
  },
  async mounted() {
      try {
          this.Posts = await getPosts();
      } catch (error) {
          console.error("Erreur lors de la récupération des articles :", error);
      } finally {
          this.loading = false;
      }
  }
}
</script>

