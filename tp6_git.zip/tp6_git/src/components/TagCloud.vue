<template>
  <div class="tag-cloud">
    <h3>Tags</h3>
    <ul>
      <li v-if="loading">Loading tags...</li>
      <li v-else v-for="tag in uniqueTags" :key="tag">
        <RouterLink :to="`/tags/${tag}`">#{{ tag }}</RouterLink>
      </li>
      <li v-if="!loading && uniqueTags.length === 0">No tags found.</li>
    </ul>
  </div>
</template>

<script>
import getPosts from "@/composables/getPosts.js";

export default {
  name: "TagCloud",

  data() {
    return {
      posts: [],
      loading: true
    };
  },

  computed: {
    uniqueTags() {
      const tagsSet = new Set();
      this.posts.forEach(post => {
        if (Array.isArray(post.tags)) {
          post.tags.forEach(tag => tagsSet.add(tag));
        }
      });
      return Array.from(tagsSet);
    }
  },

  async mounted() {
    try {
      const { posts, load } = getPosts();
      await load();
      this.posts = posts.value;
    } catch (error) {
      console.error("Erreur lors de la récupération des articles :", error);
    } finally {
      this.loading = false;
    }
  }
};
</script>

<style scoped>
.tag-cloud {
  background-color: #f9f9f9;
  padding: 1rem;
  border-radius: 8px;
  box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
}
.tag-cloud h3 {
  margin-bottom: 0.5rem;
}
.tag-cloud ul {
  list-style: none;
  padding: 0;
}
.tag-cloud li {
  margin-bottom: 0.4rem;
}
.tag-cloud a {
  color: #3498db;
  text-decoration: none;
}
.tag-cloud a:hover {
  text-decoration: underline;
}
</style>
