import { createRouter, createWebHistory } from "vue-router";
import Home from "../views/Home.vue";
import CreatePostView from "../views/CreatePostView.vue";
import PostDetailView from "../views/PostDetailView.vue";

const routes = [
  {
    path: "/",
    name: "Home",
    component: Home,
  },
  {
    path: "/addPost",
    name: "CreatePost",
    component: CreatePostView,
  },
  {
    path: "/posts/:id",
    name: "PostDetail",
    component: PostDetailView,
    props: true, // Allows us to receive `id` as a prop in PostDetailView.vue
  },
  {
    path: "/tags/:tag",
    name: "TagPosts",
    component: Home, // Reusing Home.vue to filter posts by tag
    props: true, // Allows us to receive `tag` as a prop in Home.vue
  },
  
];

const router = createRouter({
  history: createWebHistory(),
  routes,
});

export default router;
