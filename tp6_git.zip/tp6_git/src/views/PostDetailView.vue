<template>
    <h2>L'article :</h2>
    <div v-if="article">{{ article.title }} - {{ article.content }}</div>
    <div v-else>Chargement ou article introuvable..</div>
</template>

<script>
import { getPost } from "@/composables/getPost.js";
import {NavBar} from '@/components/NavBar.vue';

export default {
    name: "PostDetailView",
    data() {
        return {
            article: null
        };
    },
    async mounted() {
        const postId = this.$route.params.id;
        this.article = await getPost(postId);
    }
}
</script>
