<template>
    <div class="form-container">
        <h2>Formulaire d'ajout d'un post</h2>
        <form @submit.prevent="submitForm">
            <label for="title">Title :</label>
            <input type="text" id="title" v-model="formData.title" required>

            <label for="content">Content :</label>
            <textarea id="content" v-model="formData.content" required></textarea>

            <div class="tags-container">
                <label>Tags :</label>
                <input type="text" placeholder="Entrez le premier" v-model="tags.tag1">
                <input type="text" placeholder="Entrez le deuxième" v-model="tags.tag2">
                <input type="text" placeholder="Entrez le troisième" v-model="tags.tag3">
            </div>

            <label for="date">Date : (année-mois-jour)</label>
            <input type="text" id="date" v-model="formData.date" required>
            <span :class="datavalide ? 'valid' : 'invalid'">
                {{ datavalide ? "Date valide" : "Date non valide" }}
            </span>

            <button type="submit" :disabled="!formValide">Ajouter</button>
        </form>
    </div>
</template>

<script>
export default {
    data() {
        return {
            tags: {
                tag1: "",
                tag2: "",
                tag3: "",
            },
            formData: {
                title: "",
                content: "",
                date: "",
                tags: []
            }
        };
    },
    computed: {
        datavalide() {
            const regex = /^\d{4}-(0[1-9]|1[0-2])-(0[1-9]|[12]\d|3[01])$/;
            return regex.test(this.formData.date);
        },
        convertir() {
            return Object.values(this.tags).filter(tag => tag.trim() !== "");
        },
        formValide() {
            return this.datavalide && this.formData.title && this.formData.content;
        }
    },
    methods: {
        async addPost(newPost) {
            try {
                const response = await fetch("http://localhost:3000/posts", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify(newPost)
                });

                if (!response.ok) {
                    throw new Error(`Erreur HTTP! Statut : ${response.status}`);
                }

                const data = await response.json();
                console.log("Post ajouté avec succès :", data);
                alert("Post ajouté avec succès !");
                return data;
            } catch (err) {
                console.error("Erreur lors de l'ajout :", err);
                alert("Erreur lors de l'ajout du post.");
                return null;
            }
        },
        submitForm() {
            if (this.formValide) {
                this.formData.tags = this.convertir;
                this.addPost(this.formData);
            }
        }
    }
}
</script>

<style scoped>
.form-container {
    max-width: 500px;
    margin: auto;
    padding: 20px;
    background: #f9f9f9;
    border-radius: 8px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

h2 {
    text-align: center;
    color: #333;
}

label {
    display: block;
    margin-top: 10px;
    font-weight: bold;
}

input, textarea {
    width: 100%;
    padding: 8px;
    margin-top: 5px;
    border: 1px solid #ccc;
    border-radius: 4px;
}

textarea {
    resize: vertical;
}

.tags-container input {
    display: block;
    margin-bottom: 5px;
}

.valid {
    color: green;
}

.invalid {
    color: red;
}

button {
    width: 100%;
    padding: 10px;
    background: #28a745;
    color: white;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    margin-top: 15px;
    font-size: 16px;
}

button:disabled {
    background: #ccc;
    cursor: not-allowed;
}
</style>