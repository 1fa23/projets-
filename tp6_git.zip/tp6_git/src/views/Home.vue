<template>
  <div>
    <PostList :tag="tag" />
    <TagCloud />
  </div>
</template>

<script>
import PostList from '@/components/PostList.vue';
import TagCloud from '@/components/TagCloud.vue';

export default {
  name: "Home",
  components: { PostList, TagCloud },
  props: {
    tag: {
      type: String,
      required: false
    }
  }
}
</script>
