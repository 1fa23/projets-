// récuperer tous le data


// j'ai utiliser export pour avoir utiliser getPosts () dans des fichiers VU

// Récupérer toutes les données

// J'ai utilisé export pour pouvoir utiliser getPosts() dans des fichiers Vue

export function getPosts() {
  return fetch("http://localhost:3000/posts")
      .then(res => res.json())
      .then(data => {
          console.log(data);
          return data;
      })
      .catch(err => {
          console.error("Erreur lors de la récupération des articles :", err);
          return [];
      });
}
