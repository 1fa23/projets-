// récuperer tous le data


// j'ai utiliser export pour avoir utiliser getPosts () dans des fichiers VU

// Fonction pour récupérer un article par son ID
// Récupérer toutes les données

// J'ai utilisé export pour pouvoir utiliser getPost() dans des fichiers Vue

// Fonction pour récupérer un article par son ID
export function getPost(id) {
    return fetch(`http://localhost:3000/posts/${id}`)  // Récupérer un seul article avec /posts/:id
        .then(res => {
            if (!res.ok) {
                throw new Error(`Erreur HTTP! Statut : ${res.status}`);
            }
            return res.json();
        })
        .then(data => {
            console.log("Article récupéré :", data);
            return data;  // Retourne l'article récupéré
        })
        .catch(err => {
            console.error("Erreur lors du chargement de l'article :", err);
            return null;  // Retourne `null` en cas d'erreur
        });
}
